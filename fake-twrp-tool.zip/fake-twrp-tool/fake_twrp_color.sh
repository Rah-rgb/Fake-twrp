#!/bin/bash

# ANSI color codes for TWRP look
BG_BLUE="\e[44m"
TEXT_WHITE="\e[97m"
PROGRESS_CYAN="\e[96m"
HIGHLIGHT_YELLOW="\e[93m"
RESET="\e[0m"

# Base directories
BASE_DIR="$HOME/fake_twrp"
FLASH_DIR="$BASE_DIR/flashes"
SYS_DIR="$BASE_DIR/fake_system"
DATA_DIR="$BASE_DIR/fake_data"

mkdir -p "$FLASH_DIR" "$SYS_DIR" "$DATA_DIR"

# Display TWRP-style menu
show_menu() {
    clear
    echo -e "${BG_BLUE}${TEXT_WHITE}=============================="
    echo -e "       FAKE TWRP ADVANCED     "
    echo -e "==============================${RESET}"
    echo -e "${TEXT_WHITE}1) Flash Scripts${RESET}"
    echo -e "${TEXT_WHITE}2) Backup${RESET}"
    echo -e "${TEXT_WHITE}3) Wipe Cache${RESET}"
    echo -e "${TEXT_WHITE}4) List Fake System${RESET}"
    echo -e "${TEXT_WHITE}5) Exit${RESET}"
    echo -ne "${TEXT_WHITE}Choose an option: ${RESET}"
    read choice
}

# Log with timestamp
twrp_log() {
    echo -e "${TEXT_WHITE}[`date +%H:%M:%S`] $1${RESET}"
}

# Progress bar
progress_bar() {
    for i in $(seq 1 50); do
        printf "\r${PROGRESS_CYAN}%s: [%-50s] %d%%${RESET}" "$1" $(printf "%0.s#" $(seq 1 $i)) $((i*2))
        sleep 0.05
    done
    echo ""
}

# Flash scripts
flash_scripts() {
    echo -e "${TEXT_WHITE}Available scripts in $FLASH_DIR:${RESET}"
    ls -1 "$FLASH_DIR" | grep '\.sh$'
    echo -ne "${TEXT_WHITE}Enter scripts to flash (space-separated, or path if outside): ${RESET}"
    read scripts

    for script in $scripts; do
        if [ -f "$script" ]; then
            src="$script"
        elif [ -f "$FLASH_DIR/$script" ]; then
            src="$FLASH_DIR/$script"
        else
            twrp_log "Script not found: $script"
            continue
        fi

        twrp_log "Flashing $src..."
        progress_bar "Flashing $script"

        # Execute script in fake partitions
        bash "$src" "$SYS_DIR" "$DATA_DIR"

        twrp_log "Flash complete: $script"
        echo ""
        sleep 1
    done
}

# Backup
backup_system() {
    BK_DIR="$BASE_DIR/backup_$(date +%Y%m%d_%H%M%S)"
    mkdir -p "$BK_DIR"
    twrp_log "Backing up fake system..."
    cp -r "$SYS_DIR" "$BK_DIR/fake_system"
    cp -r "$DATA_DIR" "$BK_DIR/fake_data"
    twrp_log "Backup complete: $BK_DIR"
    sleep 1
}

# Wipe cache
wipe_cache() {
    twrp_log "Wiping cache..."
    sleep 1
    twrp_log "Cache wiped!"
    sleep 1
}

# List fake system
list_system() {
    twrp_log "Listing fake system content:"
    ls -R "$SYS_DIR"
    sleep 2
}

# Main loop
while true; do
    show_menu
    case $choice in
        1) flash_scripts ;;
        2) backup_system ;;
        3) wipe_cache ;;
        4) list_system ;;
        5) echo -e "${TEXT_WHITE}Exiting Fake TWRP.${RESET}"; exit 0 ;;
        *) echo -e "${HIGHLIGHT_YELLOW}Invalid choice!${RESET}"; sleep 1 ;;
    esac
done