include <dlfcn.h>
#include <cstdio>
#include <unistd.h>
#include <sys/mman.h>

// Example: hook a system function (open)
typedef int (*open_t)(const char*, int, ...);
open_t original_open = nullptr;

// Our hook
int hooked_open(const char* pathname, int flags, ...) {
    printf("[HOOK] open called for: %s\n", pathname);
    return original_open(pathname, flags); // call original
}

void hook_open() {
    void* handle = dlopen("libc.so", RTLD_LAZY);
    if (!handle) return;

    original_open = (open_t)dlsym(handle, "open");
    if (!original_open) return;

    // Make memory writable
    size_t pageSize = sysconf(_SC_PAGESIZE);
    uintptr_t pageStart = ((uintptr_t)original_open) & ~(pageSize - 1);
    mprotect((void*)pageStart, pageSize, PROT_READ | PROT_WRITE | PROT_EXEC);

    // Replace function pointer (simplified example)
    *(void**)&original_open = (void*)hooked_open;

    printf("Hook installed!\n");
}

int main() {
    hook_open();

    FILE* f = fopen("/system/build.prop", "r"); // triggers hook
    if(f) fclose(f);
    return 0;
}